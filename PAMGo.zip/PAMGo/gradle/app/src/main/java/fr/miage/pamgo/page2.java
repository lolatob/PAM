package fr.miage.pamgo;


import android.os.Bundle;

public class page2 {


}
